import {
  createBlockchainClaimAnchorManifest,
  createBlockchainClaimAnchorPayload,
  type BlockchainClaimAnchorPayload
} from "@traceforge/claim-anchoring";
import { SUI_CLAIM_ANCHOR_MODULE, SUI_TESTNET_NETWORK } from "@traceforge/sui-claim-anchoring";
import { isValidSuiObjectId, normalizeSuiObjectId } from "@mysten/sui/utils";
import { Transaction } from "@mysten/sui/transactions";
import { bcs } from "@mysten/sui/bcs";
import { ObjectError, type SuiClientTypes } from "@mysten/sui/client";
import type {
  VerificationClaim,
  VerificationSession,
  VerificationTraceEvent
} from "@traceforge/verification-contracts";

export interface SuiAnchorDeployment {
  readonly packageId: string;
  readonly registryId: string;
  readonly adminCapId: string;
}

export interface SuiAnchorAuthorization {
  readonly nonce: string;
  readonly deadlineMs: number;
  readonly signature: string;
  readonly signerPublicKey: string;
}

export interface SuiAnchorResult {
  readonly digest: string;
  readonly explorerUrl: string;
  /** Submission through successful execution, excluding wallet signing. */
  readonly elapsedMs: number;
}

export const SuiAnchorKey = bcs.struct("AnchorKey", {
  session_hash: bcs.vector(bcs.u8()),
  claim_index: bcs.u32()
});

export const SuiAnchorRecord = bcs.struct("AnchorRecord", {
  session_hash: bcs.vector(bcs.u8()),
  claim_index: bcs.u32(),
  manifest_hash: bcs.vector(bcs.u8()),
  evidence_root: bcs.vector(bcs.u8()),
  schema_version: bcs.u32(),
  anchored_at_ms: bcs.u64(),
  anchored_by: bcs.Address,
  verified: bcs.bool()
});

export interface SuiAnchorReader {
  getDynamicField(
    input: SuiClientTypes.GetDynamicFieldOptions
  ): Promise<SuiClientTypes.GetDynamicFieldResponse>;
}

/** Reads the immutable commitment before requesting another wallet transaction. */
export async function findSuiClaimAnchor(
  client: SuiAnchorReader,
  payload: BlockchainClaimAnchorPayload,
  deployment: SuiAnchorDeployment,
  legacyPayload?: () => Promise<BlockchainClaimAnchorPayload>
): Promise<{ matches: boolean; digest: string | null; objectUrl: string } | null> {
  try {
    const { dynamicField } = await client.getDynamicField({
      parentId: deployment.registryId,
      signal: AbortSignal.timeout(10000),
      name: {
        type: `${deployment.packageId}::${SUI_CLAIM_ANCHOR_MODULE}::AnchorKey`,
        bcs: SuiAnchorKey.serialize({
          session_hash: hexToBytes32(payload.sessionHash),
          claim_index: payload.claimIndex
        }).toBytes()
      }
    });
    const record = SuiAnchorRecord.parse(dynamicField.value.bcs);
    const expected =
      record.schema_version === 1 && payload.schemaVersion !== 1 && legacyPayload
        ? await legacyPayload()
        : payload;
    const equal = (bytes: number[], hex: string) =>
      bytes.length === 32 && bytes.every((byte, index) => byte === hexToBytes32(hex)[index]);
    return {
      matches:
        record.verified &&
        record.claim_index === expected.claimIndex &&
        record.schema_version === expected.schemaVersion &&
        equal(record.session_hash, expected.sessionHash) &&
        equal(record.manifest_hash, expected.manifestHash) &&
        equal(record.evidence_root, expected.evidenceRoot),
      digest: dynamicField.previousTransaction,
      objectUrl: `https://suiexplorer.com/object/${encodeURIComponent(dynamicField.fieldId)}?network=testnet`
    };
  } catch (error) {
    // A failed/unavailable RPC must never be mistaken for a missing anchor.
    if (error instanceof ObjectError && error.reason === "notFound") return null;
    throw error;
  }
}

export function getSuiAnchorDeployment(): SuiAnchorDeployment {
  const packageId = process.env.NEXT_PUBLIC_SUI_ANCHOR_PACKAGE_ID?.trim();
  const registryId = process.env.NEXT_PUBLIC_SUI_ANCHOR_REGISTRY_ID?.trim();
  const adminCapId = process.env.NEXT_PUBLIC_SUI_ANCHOR_ADMIN_CAP_ID?.trim();

  if (!packageId || !registryId || !adminCapId) {
    throw new Error(
      "Sui testnet anchoring is not configured yet. Deploy the Move package, then set its package, registry, and admin-cap object IDs in the web environment."
    );
  }

  return {
    packageId: normalizeObjectId(packageId, "package"),
    registryId: normalizeObjectId(registryId, "registry"),
    adminCapId: normalizeObjectId(adminCapId, "admin capability")
  };
}

export async function createSuiAnchorTransaction(
  session: VerificationSession,
  claim: VerificationClaim,
  traceEvents: readonly VerificationTraceEvent[],
  deployment: SuiAnchorDeployment
): Promise<Transaction> {
  const manifest = createBlockchainClaimAnchorManifest(session, claim, traceEvents);
  const payload = await createBlockchainClaimAnchorPayload(manifest);
  return buildSuiAnchorTransaction(payload, deployment);
}

export function buildSuiAnchorTransaction(
  payload: BlockchainClaimAnchorPayload,
  deployment: SuiAnchorDeployment,
  authorization?: SuiAnchorAuthorization
): Transaction {
  const transaction = new Transaction();
  transaction.moveCall({
    target: `${deployment.packageId}::${SUI_CLAIM_ANCHOR_MODULE}::${authorization ? "anchor_verified_claim_with_authorization" : "anchor_verified_claim"}`,
    arguments: authorization
      ? [
          transaction.object(deployment.registryId),
          transaction.object("0x6"),
          transaction.pure.vector("u8", hexToBytes32(payload.sessionHash)),
          transaction.pure.u32(payload.claimIndex),
          transaction.pure.vector("u8", hexToBytes32(payload.manifestHash)),
          transaction.pure.vector("u8", hexToBytes32(payload.evidenceRoot)),
          transaction.pure.u32(payload.schemaVersion),
          transaction.pure.vector("u8", hexToBytes(authorization.nonce)),
          transaction.pure.u64(authorization.deadlineMs),
          transaction.pure.vector("u8", hexToBytes(authorization.signature))
        ]
      : [
          transaction.object(deployment.registryId),
          transaction.object(deployment.adminCapId),
          transaction.object("0x6"),
          transaction.pure.vector("u8", hexToBytes32(payload.sessionHash)),
          transaction.pure.u32(payload.claimIndex),
          transaction.pure.vector("u8", hexToBytes32(payload.manifestHash)),
          transaction.pure.vector("u8", hexToBytes32(payload.evidenceRoot)),
          transaction.pure.u32(payload.schemaVersion)
        ]
  });
  return transaction;
}

/** One-time publisher setup: store the server's compressed secp256k1 public key. */
export function buildSuiSignerSetupTransaction(
  signerPublicKey: string,
  deployment: SuiAnchorDeployment
): Transaction {
  const transaction = new Transaction();
  transaction.moveCall({
    target: `${deployment.packageId}::${SUI_CLAIM_ANCHOR_MODULE}::set_signer_public_key`,
    arguments: [
      transaction.object(deployment.registryId),
      transaction.object(deployment.adminCapId),
      transaction.pure.vector("u8", hexToBytes(signerPublicKey))
    ]
  });
  return transaction;
}

export function getSuiTestnetTransactionUrl(digest: string): string {
  return `https://suiexplorer.com/txblock/${encodeURIComponent(digest)}?network=testnet`;
}

function normalizeObjectId(value: string, label: string): string {
  if (!isValidSuiObjectId(value)) {
    throw new Error(`The configured Sui ${label} ID is invalid.`);
  }
  return normalizeSuiObjectId(value);
}

function hexToBytes32(value: string): number[] {
  if (!/^0x[0-9a-f]{64}$/i.test(value)) {
    throw new TypeError("Sui anchor hashes must be exactly 32 bytes.");
  }
  return Array.from({ length: 32 }, (_, index) =>
    Number.parseInt(value.slice(2 + index * 2, 4 + index * 2), 16)
  );
}

function hexToBytes(value: string): number[] {
  if (!/^0x[0-9a-f]*$/i.test(value) || value.length % 2 !== 0)
    throw new TypeError("Sui authorization bytes are invalid.");
  return Array.from({ length: (value.length - 2) / 2 }, (_, index) =>
    Number.parseInt(value.slice(2 + index * 2, 4 + index * 2), 16)
  );
}

export const SUI_ANCHOR_TESTNET = SUI_TESTNET_NETWORK;
