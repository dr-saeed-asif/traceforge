# tamper-forge

Updates round-3 manuscript Table 10. Frozen policy 3.1.0 / extraction 3.2.0. Raw metrics use main exact one-to-one alignment. Phrasing coverage in the root Table 10 report uses the separate author-supplied containment/Dice method; do not merge them. Failures are retained.
