# Table 10 acceptance reproduction

See acceptance-checks.csv for exact count and displayed-CI checks. main-exact-statistics.csv and phrasing-coverage-statistics.csv use different alignment estimands and are deliberately separate. CP bounds assume iid Bernoulli trials; session/family bootstrap handles clustering. No seeds or models are pooled. Capture architecture is a design contract, not a deployed security fix.
